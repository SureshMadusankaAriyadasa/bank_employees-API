***Java Development Kit (JDK 1.8 or newer) a).MySQL Driver b).Spring Data JPA c).Spring Web

Step 1: install Eclipse

Step 2: open Eclipse ----> click "Help" tab ----> click "Eclipse Marketplace" ----> Search "Spring STS" ---> install Spring tools

Step 3: Download the Zip file. and UnZip this file.

Step 4: Create MySQL Database to xampp or wamp. DataBase name="bank_employees"

Open the this database Link: http://localhost/phpmyadmin/db_structure.php?server=1&db=bank_employees

Click ----> "import" tab ----> Click "Choose File" ---->Select "bank_employees.sql" in the project folder. ---> Click "Go" Button.

Step 5: Open the Eclipse ---> Click "import" ---> Select "existing Maven Project" ---> Click "Next" button ---> Browse the project Directory ---> Click "Finish" button.................

Step 6: Test
ex:
http://localhost:2121/employee/all_emp/
http://localhost:2121/branch/all_branches/
http://localhost:2121/bank/search/2
http://localhost:2121/bank/all/